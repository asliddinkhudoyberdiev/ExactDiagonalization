#include <cstdio>      
#include <cstdlib>
#include <cctype>

//Methoden, die Zahlen aus einem String extrahieren

//liefert die erste Zahl eines Strings zurück
double get_zahl1(char *str);

//liefert die dritte Zahl eines Strings zurück
double get_zahl2(char *str);

//liefert die dritte Zahl eines Strings zurück
double get_zahl3(char *str);

//liefert die vierte Zahl eines Strings zurück
double get_zahl4(char *str);